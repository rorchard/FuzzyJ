#!/bin/sh
# *******************************************************************
# Run a complete set of Jess-based tests 
# *******************************************************************

# 
# Run the tests
# 
# This shell script was run under the cygwin system so some changes 
# may be needed to run uner other unix variants. 
#

echo "Running All FuzzyJess test programs ..."

JAVA=d:/javasoft/jdk1.4/bin/java
JESS_JAR=./jess.jar
FUZZYJ_JAR=./fuzzyj15a.jar
export JAVA
export JESS_JAR
export FUZZYJ_JAR

./runFuzzyMatchTests.sh
./runFuzzyCompilerTest.sh

echo "Testing Completed"



